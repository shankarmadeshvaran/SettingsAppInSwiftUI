


import SwiftUI
import Combine

class Settings: BindableObject {
    var didChange = PassthroughSubject<Void, Never>()

   var isBluetoothOn = false { didSet { update() } }
    
    static let types = ["Off","On"]
    var type = 0 { didSet { update() } }
    
    var isToggleOn = false { didSet { update() } }
    
    func update() {
        didChange.send(())
    }
}







