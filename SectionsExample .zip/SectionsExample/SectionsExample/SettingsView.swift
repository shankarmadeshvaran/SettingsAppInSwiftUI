
//SettingsView.swift
import SwiftUI
import Combine

struct SettingsView : View {
    @ObjectBinding var setting = Settings()
    
    var body: some View {
        NavigationView {
            Form {
                Section {
                    SignInView()
                }
                Section {
                    BluetoothView()
                    WiFiView()
                }
                ForEach(Option.options.identified(by: \.id)) { settingOption in
                    OptionRow(option: settingOption)
                }
                }
                .navigationBarTitle(Text("Settings")).font(.largeTitle)
        }
    }
}

struct OptionRow: View {
    let option: Option
    var body: some View {
        Group() {
            if option.isAddSection {
                Section {
                    OptionSettingsView(option: option)
                }
            } else {
                OptionSettingsView(option: option)
            }
        }
    }
}


struct OptionSettingsView : View {
    let option: Option
    
    var body: some View {
        return NavigationButton(destination: OptionInnerDetail(option: option)) {
            HStack {
                Image("default")
                    .resizable()
                    .cornerRadius(12)
                    .frame(width: 25, height: 25)
                    .clipped()
                    .aspectRatio(contentMode: .fit)
                Text(option.title)
                    .color(.blue)
                    .font(.system(size: 18))
            }
        }
    }
}




struct OptionInnerDetail: View {
    let option: Option
    var body: some View {
        Form {
            ForEach(option.values.identified(by: \.title)) { valuesOption in
                OptionInnerView(value: valuesOption)
            }
            }
            .navigationBarTitle(Text(option.title), displayMode: .inline)
    }
}

struct OptionInnerView: View {
    let value: InnerOptionValues
    var body: some View {
        Group() {
            if value.isAddSection && !value.isUseToggle {
                Section(header: Text(value.headerTitle)) {
                    InnerView(value: value)
                }
            } else if !value.isAddSection && value.isUseToggle {
                ToggleView(value: value)
            } else if value.isAddSection && value.isUseToggle {
                Section(header: Text(value.headerTitle)) {
                    ToggleView(value: value)
                }
            } else {
                InnerView(value: value)
            }
        }
    }
}



struct ToggleView: View {
    let value: InnerOptionValues
    @ObjectBinding var toggle = Settings()
    
    var body: some View {
        HStack {
            Image("default")
                .resizable()
                .cornerRadius(12)
                .frame(width: 25, height: 25)
                .clipped()
                .aspectRatio(contentMode: .fit)
            
            Toggle(isOn: $toggle.isToggleOn) {
                Text(value.title)
                    .color(.blue)
                    .font(.system(size: 18))
            }
        }
    }
}




struct InnerView: View {
    let value: InnerOptionValues
    
    var body: some View {
        return NavigationButton(destination: EndView(value: value)) {
            HStack {
                Image("default")
                    .resizable()
                    .cornerRadius(12)
                    .frame(width: 25, height: 25)
                    .clipped()
                    .aspectRatio(contentMode: .fit)
                Text(value.title)
                    .color(.blue)
                    .font(.system(size: 18))
            }
        }
    }
}



struct EndView: View {
    let value: InnerOptionValues
    
    var body: some View {
        return NavigationButton(destination: EndView(value: value)) {
            
            Text("Coming Soon!!!")
                .font(.system(size: 25))
                .color(.blue)
            } .navigationBarTitle(Text(value.title), displayMode: .inline)
    }
}
