//
//  SectionsExampleUnitTests.swift
//  SectionsExampleUnitTests
//
//  Created by User on 01/07/19.
//  Copyright © 2019 Heptagon. All rights reserved.
//

import XCTest

@testable import SectionsExample

class SectionsExampleUnitTests: XCTestCase {


    override func setUp() {
        
    }

    override func tearDown() {
       
    }

    func testExample() {
        
    }

}
